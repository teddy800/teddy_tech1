import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ChatService extends Remote {
    void sendMessage(String message, String sender) throws RemoteException;
    void registerClient(ChatService client, String clientName) throws RemoteException;
    void receiveMessage(String message, String sender) throws RemoteException;
}