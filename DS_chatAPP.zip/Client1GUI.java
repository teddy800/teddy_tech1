import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class Client1GUI extends JFrame implements ChatService {
    private final JPanel chatPanel;
    private JScrollPane scrollPane;
    private JTextField inputField;
    private JButton sendButton, clearButton;
    private ChatService chatService;
    private String clientName;

    public Client1GUI() {
        clientName = JOptionPane.showInputDialog(this, "Enter your name:", "Client Name", JOptionPane.PLAIN_MESSAGE);
        if (clientName == null || clientName.trim().isEmpty()) {
            clientName = "Anonymous";
        }

        setTitle(clientName + " - Chat");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        getContentPane().setBackground(new Color(126, 198, 225));

        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        chatPanel.setBackground(Color.WHITE);

        scrollPane = new JScrollPane(chatPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputField = new JTextField();
        inputField.setFont(new Font("Arial", Font.PLAIN, 14));
        inputField.setPreferredSize(new Dimension(200, 40));

        sendButton = new JButton("Send");
        clearButton = new JButton("Clear");

        sendButton.setBackground(new Color(70, 130, 180));
        sendButton.setForeground(Color.WHITE);
        sendButton.setFont(new Font("Arial", Font.BOLD, 14));
        sendButton.setPreferredSize(new Dimension(120, 40));

        clearButton.setBackground(new Color(220, 20, 60));
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setPreferredSize(new Dimension(120, 40));

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(inputField, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(sendButton);
        buttonPanel.add(clearButton);

        bottomPanel.add(buttonPanel, BorderLayout.EAST);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        connectToServer();

        sendButton.addActionListener(e -> sendMessage());
        clearButton.addActionListener(e -> {
            chatPanel.removeAll();
            chatPanel.revalidate();
            chatPanel.repaint();
        });
    }

    private void connectToServer() {
        try {
            Registry registry = LocateRegistry.getRegistry("10.232.81.205", 1099);
            chatService = (ChatService) registry.lookup("ChatService");
            ChatService stub = (ChatService) UnicastRemoteObject.exportObject(this, 0);
            chatService.registerClient(stub, clientName);
            addMessage("Connected to the chat server as " + clientName + ".", "System", "left");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the server.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void sendMessage() {
        try {
            String message = inputField.getText().trim();
            if (!message.isEmpty()) {
                chatService.sendMessage(message, clientName);
                addMessage("You: " + message, clientName, "right");
                inputField.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void receiveMessage(String message, String sender) throws RemoteException {
        SwingUtilities.invokeLater(() -> {
            if (!sender.equals(clientName)) {
                addMessage(sender + ": " + message, sender, "left");
            }
        });
    }

    private void addMessage(String text, String sender, String alignment) {
        JPanel messagePanel = new JPanel(new FlowLayout(alignment.equals("right") ? FlowLayout.RIGHT : FlowLayout.LEFT));
        messagePanel.setBackground(Color.WHITE);

        JLabel messageLabel = new JLabel("<html><body style='width: 200px;'>" + text + "</body></html>");
        messageLabel.setOpaque(true);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        if (alignment.equals("right")) {
            messageLabel.setBackground(new Color(173, 216, 230));
            messageLabel.setForeground(Color.BLACK);
            messageLabel.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
        } else {
            messageLabel.setBackground(new Color(240, 240, 240));
            messageLabel.setForeground(new Color(50, 50, 50));
            messageLabel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 2));
        }

        messageLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        messagePanel.add(messageLabel);
        chatPanel.add(messagePanel);
        chatPanel.revalidate();
        chatPanel.repaint();
        scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum());

        messagePanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem deleteItem = new JMenuItem("Delete");
                    deleteItem.addActionListener(evt -> {
                        chatPanel.remove(messagePanel);
                        chatPanel.revalidate();
                        chatPanel.repaint();
                    });
                    menu.add(deleteItem);
                    menu.show(messagePanel, e.getX(), e.getY());
                }
            }
        });
    }

    @Override
    public void sendMessage(String message, String sender) throws RemoteException {}

    @Override
    public void registerClient(ChatService client, String clientName) throws RemoteException {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Client1GUI client = new Client1GUI();
            client.setVisible(true);
        });
    }
}
