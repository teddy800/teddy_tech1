import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class ChatServiceImpl extends UnicastRemoteObject implements ChatService {
    private List<ChatService> clients = new ArrayList<>();
    private List<String> clientNames = new ArrayList<>();

    protected ChatServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public void sendMessage(String message, String sender) throws RemoteException {
        System.out.println("Message from " + sender + ": " + message);
        broadcastMessage(message, sender);
    }

    @Override
    public void registerClient(ChatService client, String clientName) throws RemoteException {
        clients.add(client);
        clientNames.add(clientName);
        System.out.println(clientName + " has joined the chat.");
        broadcastMessage(clientName + " has joined the chat.", "Server");
    }

    @Override
    public void receiveMessage(String message, String sender) throws RemoteException {
        // This method is for clients to implement
    }

    private void broadcastMessage(String message, String sender) throws RemoteException {
        for (ChatService client : clients) {
            client.receiveMessage(message, sender);
        }
    }
}